module.exports.load = async function(app, db) {
    // works
}